Welcome to WUM
=======================================================================
WUM is a CLI application which keeps WSO2 products up-to-date.
WUM determines which updates are new and relevant for your WSO2 product,
downloads and installs them.

WUM connects to WSO2 Update to get latest updates for your WSO2 Products.
WSO2 Update is a service that provides you continuous access to all bug
fixes and improvements to WSO2 products.

Available Commands and Flags
=======================================================================

Available Commands:
  init         Initialize wum with your WSO2 credentials
  search       Search products containing specific keyword(s)
  add          Add or download a product
  check-update Check for new updates for products
  update       Update products in your local repository
  diff         Create a diff between two updated distributions
  list         List products in your local repository
  describe     Show details of products in your local repository
  delete       Delete products in your local repository
  config       Change wum configuration
  version      Display wum version information

Flags:
  -h, --help      help for wum
  -v, --verbose   enable verbose mode


Installing WUM
=======================================================================

For Linux users:
    1) Download the archive and extract it into /usr/local.

        For example:
        tar -C /usr/local -xzf wum-1.0-linux-x64.tar.gz

    (Typically these commands must be run as root or through sudo.)

    2) Add /usr/local/wum/bin to the PATH environment variable.
       You can do this by adding this line to your/etc/profile
       (for a system-wide installation) or $HOME/.profile:

        export PATH=$PATH:/usr/local/wum/bin

For Mac OS X and Windows users:
    You need to open the os specified installer and follow the instructions.
    These instructions are available at http://wso2.com/update


Getting Started
=======================================================================
Open a terminal or cmd (in Windows) and run 'wum' as follows.

    $ wum

You will see first help page which contains usage details,
brief descriptions of available commands and flags.

1) Initialize WUM with your WSO2 credentials

    $ wum init
    You need a WSO2 account to start using wum.
    Don't have one yet? Sign up at https://wso2.com/user/register

    Please enter your WSO2 credentials to continue
    Username: user@wso2.com
    Password for 'user@wso2.com':
    Authenticating...
    Done!

WUM maintains a local product repository in your machine, where it stores
WSO2 product distributions. Whenever you update a product, WUM creates a new
distribution with all these updates and stores it in this repository.
By default, WUM creates this repository in the user’s home directory, but you
have the option to change this as well.

2) Search WSO2 products

    List all the WUM supported WSO2 products
    $ wum search

    wso2am-2.1.0            - API Manager
    wso2am-2.0.0            - API Manager
    wso2am-analytics-2.1.0  - API Manager Analytics
    wso2am-analytics-2.0.0  - API Manager Analytics
    wso2cep-4.2.0           - Complex Event Processor
    wso2das-3.1.0           - Data Analytics Server
    wso2dss-3.5.1           - Data Services Server
    wso2ei-6.1.1            - Enterprise Integrator
    wso2ei-6.1.0            - Enterprise Integrator
    wso2ei-6.0.0            - Enterprise Integrator
    wso2emm-2.2.0           - Enterprise Mobility Manager
    wso2esb-5.0.0           - Enterprise Service Bus
    wso2esb-4.9.0           - Enterprise Service Bus
    wso2esb-analytics-5.0.0 - Enterprise Service Bus Analytics
    wso2greg-5.4.0          - Governance Registry
    wso2is-5.3.0            - Identity Server
    wso2is-5.2.0            - Identity Server
    wso2is-analytics-5.3.0  - Identity Server Analytics
    wso2is-analytics-5.2.0  - Identity Server Analytics
    wso2is-km-5.3.0         - IS as Key Manager
    wso2mb-3.2.0            - Message Broker

    What's next?
      use "wum add <product>" to download a product
      e.g "wum add wso2am-2.1.0" to download API Manager 2.1.0

    Search WSO2 products match with the specified keywords
    $ wum search esb

    wso2esb-5.0.0           - Enterprise Service Bus
    wso2esb-4.9.0           - Enterprise Service Bus
    wso2esb-analytics-5.0.0 - Enterprise Service Bus Analytics

    What's next?
      use "wum add <product>" to download a product
      e.g "wum add wso2esb-5.0.0" to download Enterprise Service Bus 5.0.0

3) Add or Download WSO2 products

   Download wso2esb-5.0.0
   $ wum add wso2esb-5.0.0
    The product, "wso2esb-5.0.0.zip", will be downloaded.
    After this operation, 218.1MB of additional disk space will be used.
    Do you want to continue? [Y/n] y
    Downloading product wso2esb-5.0.0...
    Successfully added to following location:
    ~/.wum-wso2/products/wso2esb/5.0.0/wso2esb-5.0.0.zip

    What's next?
      use "wum check-update wso2esb-5.0.0" to check for updates
      use "wum update wso2esb-5.0.0" to install latest updates

   Add an already downloaded product
   # wum add --file ~/dist/wso2/esb/wso2esb-5.0.0.zip

3) Check for update for products

    Check for updates for all the products in your local repository
    $ wum check-update

    Check for updates for only the wso2esb-5.0.0
    $ wum check-update wso2esb-5.0.0

4) Install latest updates

    Update all the products in your local repository
    $ wum update

    Update wso2esb-5.0.0
    $ wum update wso2esb-5.0.0

5) List products in your local repository

    $ wum list

6) Show details of products in your local repository

    $ wum describe

7) Create a diff between two updated distributions

    $ wum diff wso2esb-5.0.0.1477313239710.zip wso2esb-5.0.0.1481113479731.zip


Changing your local product repository location
=======================================================================

    $ wum config local.product.repo ~/wso2/my-product-repo